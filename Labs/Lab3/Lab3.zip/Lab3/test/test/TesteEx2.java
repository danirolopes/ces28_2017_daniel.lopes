package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import Ex2.AbstractFactory;
import Ex2.Address;
import Ex2.Date;
import Ex2.Person;
import Ex2.Phone;

public class TesteEx2 {

	
	@Test
	public void testDateIngles() {
		AbstractFactory idiomaFactory = AbstractFactory.getIdiomaFactory("Ingles");
		
		Date date = idiomaFactory.createDate(1,2,2000);

		assertEquals(date.toPrint(), "2/1/2000");
	}
	
	@Test
	public void testDatePortugues() {
		AbstractFactory idiomaFactory = AbstractFactory.getIdiomaFactory("Portugues");
		
		Date date = idiomaFactory.createDate(1,2,2000);
		
		assertEquals(date.toPrint(), "1/2/2000");
	}
	
	@Test
	public void testAddressIngles()
	{
		AbstractFactory idiomaFactory = AbstractFactory.getIdiomaFactory("Ingles");
		
		Address address = idiomaFactory.createAddress("Rua H8B", 234, "S�o Jos� dos Campos-SP, Brasil");
		
		assertEquals(address.toPrint(), "234, Rua H8B, S�o Jos� dos Campos-SP, Brasil");
	}

	@Test
	public void testAddressPortugues()
	{
		AbstractFactory idiomaFactory = AbstractFactory.getIdiomaFactory("Portugues");
		
		Address address = idiomaFactory.createAddress("Rua H8B", 234, "S�o Jos� dos Campos-SP, Brasil");
		
		assertEquals(address.toPrint(), "Rua H8B, 234, S�o Jos� dos Campos-SP, Brasil");
	}
	
	@Test
	public void testPhoneIngles()
	{
		AbstractFactory idiomaFactory = AbstractFactory.getIdiomaFactory("Ingles");
		
		Phone phone = idiomaFactory.createPhone("12", "91234-5678");
		
		assertEquals(phone.toPrint(), "+1 12-91234-5678");
	}
	
	@Test
	public void testPhonePortugues()
	{
		AbstractFactory idiomaFactory = AbstractFactory.getIdiomaFactory("Portugues");
		
		Phone phone = idiomaFactory.createPhone("12", "91234-5678");
		
		assertEquals(phone.toPrint(), "+55 (12) 91234-5678");
	}	
	
	@Test
	public void testPersonIngles()
	{
		AbstractFactory idiomaFactory = AbstractFactory.getIdiomaFactory("Ingles");
		
		Phone phone = idiomaFactory.createPhone("12", "91234-5678");
		Person person = idiomaFactory.createPerson("Daniel Lopes", "danirolopes@gmail.com", phone);
		
		assertEquals(person.name(), "Mr. Daniel Lopes");
	}
	
	@Test
	public void testPersonPortugues()
	{
		AbstractFactory idiomaFactory = AbstractFactory.getIdiomaFactory("Portugues");
		
		Phone phone = idiomaFactory.createPhone("12", "91234-5678");
		Person person = idiomaFactory.createPerson("Daniel Lopes", "danirolopes@gmail.com", phone);
		
		assertEquals(person.name(), "Sr. Daniel Lopes");
	}
}
