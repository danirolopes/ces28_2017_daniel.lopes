package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import Ex3Ex4.Bridge;
import Ex3Ex4.ComercialLetterBuilder;
import Ex3Ex4.FaturaLetterBuilder;
import Ex3Ex4.Letter;
import Ex3Ex4.LetterBuilder;

public class TesteEx3Ex4 {

	@Test
	public void testFaturaIngles() {
		Bridge bridge = new Bridge("Ingles");
		bridge.setDate(20, 10, 2017);
		bridge.setAddressSender("Rua H8B", 234, "S�o Jos� dos Campos-SP, Brasil");
		bridge.setAddressDestiny("River Street", 10, "Savannah-GA, United States");
		bridge.setPhoneSender("12", "123456789");
		bridge.setPhoneDestinatary("12", "123412345");
		bridge.setSender("Daniel Lopes", "danirolopes@gmail.com");
		bridge.setDestinatary("Tommy Hurst", "tommyhurst@gmail.com");
		
		LetterBuilder builder = new FaturaLetterBuilder(bridge);
		Letter letter = builder.getLetter();
		
		assertEquals(letter.toPrint(), "10/20/2017\n\nMr. Daniel Lopes\n234, Rua H8B, S�o Jos� dos Campos-SP, Brasil\n\nMr. Tommy Hurst\n10, River Street, Savannah-GA, United States\n\nDear Mr. Tommy Hurst\n\nAqui est� a fatura correspondente ao mes 10:\n\n\nObrigado pela prefer�ncia,\n\n\n                   Mr. Daniel Lopes\n             SAC:+1 12-123456789\n            email:danirolopes@gmail.com");
	}
	
	@Test
	public void testFaturaPortugues() {
		Bridge bridge = new Bridge("Portugues");
		bridge.setDate(20, 10, 2017);
		bridge.setAddressSender("Rua H8B", 234, "S�o Jos� dos Campos-SP, Brasil");
		bridge.setAddressDestiny("River Street", 10, "Savannah-GA, United States");
		bridge.setPhoneSender("12", "123456789");
		bridge.setPhoneDestinatary("12", "123412345");
		bridge.setSender("Daniel Lopes", "danirolopes@gmail.com");
		bridge.setDestinatary("Tommy Hurst", "tommyhurst@gmail.com");
		
		LetterBuilder builder = new FaturaLetterBuilder(bridge);
		Letter letter = builder.getLetter();
		
		assertEquals(letter.toPrint(), "20/10/2017\n\nSr. Daniel Lopes\nRua H8B, 234, S�o Jos� dos Campos-SP, Brasil\n\nSr. Tommy Hurst\nRiver Street, 10, Savannah-GA, United States\n\nDear Sr. Tommy Hurst\n\nAqui est� a fatura correspondente ao mes 10:\n\n\nObrigado pela prefer�ncia,\n\n\n                   Sr. Daniel Lopes\n             SAC:+55 (12) 123456789\n            email:danirolopes@gmail.com");
	}
	
	@Test
	public void testComercialIngles() {
		Bridge bridge = new Bridge("Ingles");
		bridge.setDate(20, 10, 2017);
		bridge.setAddressSender("Rua H8B", 234, "S�o Jos� dos Campos-SP, Brasil");
		bridge.setAddressDestiny("River Street", 10, "Savannah-GA, United States");
		bridge.setPhoneSender("12", "123456789");
		bridge.setPhoneDestinatary("12", "123412345");
		bridge.setSender("Daniel Lopes", "danirolopes@gmail.com");
		bridge.setDestinatary("Tommy Hurst", "tommyhurst@gmail.com");
		
		LetterBuilder builder = new ComercialLetterBuilder(bridge);
		Letter letter = builder.getLetter();
		
		assertEquals(letter.toPrint(), "10/20/2017\n\nMr. Daniel Lopes\n234, Rua H8B, S�o Jos� dos Campos-SP, Brasil\n\nMr. Tommy Hurst\n10, River Street, Savannah-GA, United States\n\nDear Mr. Tommy Hurst\n\nSincerely,\n\n\n          __________________\n               Mr. Daniel Lopes\n             +1 12-123456789\n            email:danirolopes@gmail.com");
	}
	
	@Test
	public void testComecialPortugues() {
		Bridge bridge = new Bridge("Portugues");
		bridge.setDate(20, 10, 2017);
		bridge.setAddressSender("Rua H8B", 234, "S�o Jos� dos Campos-SP, Brasil");
		bridge.setAddressDestiny("River Street", 10, "Savannah-GA, United States");
		bridge.setPhoneSender("12", "123456789");
		bridge.setPhoneDestinatary("12", "123412345");
		bridge.setSender("Daniel Lopes", "danirolopes@gmail.com");
		bridge.setDestinatary("Tommy Hurst", "tommyhurst@gmail.com");
		
		LetterBuilder builder = new ComercialLetterBuilder(bridge);
		Letter letter = builder.getLetter();
		
		System.out.println(letter.toPrint());
		assertEquals(letter.toPrint(), "20/10/2017\n\nSr. Daniel Lopes\nRua H8B, 234, S�o Jos� dos Campos-SP, Brasil\n\nSr. Tommy Hurst\nRiver Street, 10, Savannah-GA, United States\n\nDear Sr. Tommy Hurst\n\nSincerely,\n\n\n          __________________\n               Sr. Daniel Lopes\n             +55 (12) 123456789\n            email:danirolopes@gmail.com");
	}
	

}
