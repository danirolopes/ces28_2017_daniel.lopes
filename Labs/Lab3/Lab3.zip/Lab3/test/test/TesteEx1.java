package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import Ex1.Address;
import Ex1.ComercialLetterBuilder;
import Ex1.Date;
import Ex1.FaturaLetterBuilder;
import Ex1.Letter;
import Ex1.LetterBuilder;
import Ex1.Person;
import Ex1.Phone;
import Ex1.PresidentialLetterBuilder;

public class TesteEx1 {

	protected Person sender_;
	protected Person destinatary_;
	protected  Address addressSender_;
	protected  Address addressDestiny_;
	protected  Date date_;
	protected Phone phone1_;
	protected Phone phone2_;
	
	@Before
	public void setup()
	{
		phone1_ = new Phone("12345678");
		phone2_ = new Phone("87654321");
		sender_ = new Person("Daniel Lopes", "danirolopes@gmail.com", phone1_);
		destinatary_ = new Person("Tommy Hurst", "tommyhurst@gmail.com", phone2_);
		addressSender_ = new Address("Rua H8B, 234, S�o Jos� dos Campos-SP, Brasil");
		addressDestiny_ = new Address("River Streer, 10, Savannah-GA, United States");
		date_ = new Date(20,10,2017);
	}
	
	@Test
	public void testComercialLetter()
	{
		LetterBuilder builder = new ComercialLetterBuilder(sender_, destinatary_, addressSender_, addressDestiny_, date_);
		Letter letter = builder.getLetter();
		
		assertEquals(letter.toPrint(),"20/10/2017\n\nDaniel Lopes\nRua H8B, 234, S�o Jos� dos Campos-SP, Brasil\n\nTommy Hurst\nRiver Streer, 10, Savannah-GA, United States\n\nDear Tommy Hurst\n\nSincerely,\n\n\n          __________________\n               Daniel Lopes\n             12345678\n            email:danirolopes@gmail.com");
	}
	
	@Test
	public void testFaturaLetter()
	{
		LetterBuilder builder = new FaturaLetterBuilder(sender_, destinatary_, addressSender_, addressDestiny_, date_);
		Letter letter = builder.getLetter();
		
		System.out.println(letter.toPrint());
		
		assertEquals(letter.toPrint(),"20/10/2017\n\nDaniel Lopes\nRua H8B, 234, S�o Jos� dos Campos-SP, Brasil\n\nTommy Hurst\nRiver Streer, 10, Savannah-GA, United States\n\nDear Tommy Hurst\n\nAqui est� a fatura correspondente ao mes 10:\n\n\nObrigado pela prefer�ncia,\n\n\n                   Daniel Lopes\n             SAC:12345678\n            email:danirolopes@gmail.com");
	}
	
	@Test
	public void testPresidentialLetter()
	{
		LetterBuilder builder = new PresidentialLetterBuilder(sender_, destinatary_, addressSender_, addressDestiny_, date_);
		Letter letter = builder.getLetter();
		
		assertEquals(letter.toPrint(),"20/10/2017\n\nDaniel Lopes\nRua H8B, 234, S�o Jos� dos Campos-SP, Brasil\n\nTommy Hurst\nRiver Streer, 10, Savannah-GA, United States\n\nPresident Tommy Hurst\n\nSincerely,\n\n\n          __________________\n               Daniel Lopes\n             12345678\n            email:danirolopes@gmail.com");
	}

}
