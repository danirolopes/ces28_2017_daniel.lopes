package Ex3Ex4;

public abstract class Date {
	protected final int dia_;
	protected final int mes_;
	protected final int ano_;
	
	protected Date(int dia, int mes, int ano)
	{
		dia_ = dia;
		mes_ = mes;
		ano_ = ano;
	}
	
	public abstract String toPrint();
	
	public int getDia() {
		return dia_;
	}

	public int getMes() {
		return mes_;
	}

	public int getAno() {
		return ano_;
	}

}
