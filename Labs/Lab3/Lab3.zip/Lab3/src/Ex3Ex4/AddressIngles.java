package Ex3Ex4;

public class AddressIngles extends Address{

	AddressIngles(String rua, int number, String resto)
	{
		super(rua, number, resto);
	}
	
	public String toPrint()
	{
		return Integer.toString(number_)+", "+rua_+", "+cidadeEstadoPais_;
	}
}
