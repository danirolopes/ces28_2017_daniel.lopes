package Ex3Ex4;

public class PersonPortugues extends Person{
	PersonPortugues(String name, String email, Phone phone)
	{
		super(name, email, phone);
	}
	
	public  String name()
	{
		return "Sr. "+name_;
	}
	
	public  String email()
	{
		return email_;
	}
	
}
