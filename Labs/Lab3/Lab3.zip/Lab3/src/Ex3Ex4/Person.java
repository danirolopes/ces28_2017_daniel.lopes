package Ex3Ex4;

public abstract class Person {
	protected final String name_;
	protected final String email_;
	protected final Phone phone_;
	
	protected Person(String name, String email, Phone phone)
	{
		name_ = name;
		email_ = email;
		phone_ = phone;
	}
	
	public abstract String name();
	
	public abstract String email();
	
	public  Phone phone()
	{
		return phone_;
	}
}
