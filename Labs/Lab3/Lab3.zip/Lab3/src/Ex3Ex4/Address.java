package Ex3Ex4;

public abstract class Address {
	protected final String rua_;
	protected final int number_;
	protected final String cidadeEstadoPais_;
		
	protected Address(String rua, int number, String cidadeEstadoPais)
	{
		rua_ = rua;
		number_ = number;
		cidadeEstadoPais_ = cidadeEstadoPais;
	}
	
	public abstract String toPrint();
	
	
	
}
