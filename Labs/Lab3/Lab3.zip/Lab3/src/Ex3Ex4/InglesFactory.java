package Ex3Ex4;

public class InglesFactory extends AbstractFactory{
	InglesFactory()	{}
	
	public Date createDate(int dia, int mes, int ano)
	{
		return new DateIngles(dia, mes, ano);
	}
	
	public Address createAddress(String rua, int number, String cidadeEstadoPais)
	{
		return new AddressIngles(rua, number, cidadeEstadoPais);
	}

	public Phone createPhone(String DDD, String number)
	{
		return new PhoneIngles(DDD, number);
	}
	
	public Person createPerson(String name, String email, Phone phone)
	{
		return new PersonIngles(name, email, phone);
	}
}
