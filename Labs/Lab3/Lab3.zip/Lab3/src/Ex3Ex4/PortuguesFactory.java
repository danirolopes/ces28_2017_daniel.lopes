package Ex3Ex4;

public class PortuguesFactory extends AbstractFactory {
	PortuguesFactory()
	{
		
	}
	
	public Date createDate(int dia, int mes, int ano)
	{
		return new DatePortugues(dia, mes, ano);
	}
	
	public Address createAddress(String rua, int number, String cidadeEstadoPais)
	{
		return new AddressPortugues(rua, number, cidadeEstadoPais);
	}
	
	public Phone createPhone(String DDD, String number)
	{
		return new PhonePortugues(DDD, number);
	}
	
	public Person createPerson(String name, String email, Phone phone)
	{
		return new PersonPortugues(name, email, phone);
	}
}
