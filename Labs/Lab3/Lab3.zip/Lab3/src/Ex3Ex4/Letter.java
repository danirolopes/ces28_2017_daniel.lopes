package Ex3Ex4;

public class Letter {
	private final Person sender_;
	private final Person destinatary_;
	private final Address addressSender_;
	private final Address addressDestiny_;
	private final Date date_;
	private final String language_;
	
	private final String header_;
	private final String body_;
	private final String conclusion_;
	private final String signature_;

	
	Letter(LetterBuilder builder)
	{
		header_ = builder.header();
		body_ = builder.body();
		conclusion_ = builder.conclusion();
		signature_ = builder.signature();
		
		sender_ = builder.getSender();
		destinatary_ = builder.getDestinatary();
		addressSender_ = builder.getAddrSender();
		addressDestiny_ = builder.getAddrDestiny();
		date_ = builder.getDate();
		language_ = builder.getLanguage();
		
	}
	
	public String toPrint()
	{
		return header_ + body_ + conclusion_ + signature_;
	}
	
	public Person getSender() {
		return sender_;
	}
	
	public Person getDestinatary()
	{
		return destinatary_;
	}
	
	public Address getAddrSender() {
		return addressSender_;
	}
	
	public Address getAddrDestiny() {
		return addressDestiny_;
	}
	
	public Date getDate()
	{
		return date_;
	}

	public String getLanguage() {
		return language_;
	}
}
