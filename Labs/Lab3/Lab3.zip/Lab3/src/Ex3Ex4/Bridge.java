package Ex3Ex4;

public class Bridge {
	private final AbstractFactory factory;
	
	private Person sender_ = null;
	private Person destinatary_= null;
	private Phone phoneSender_ = null;
	private Phone phoneDestinatary_= null;
	private  Address addressSender_= null;
	private  Address addressDestiny_= null;
	private  Date date_= null;
	private final String language_;
	
	public Bridge(String language)
	{
		language_ = language;
		factory = AbstractFactory.getIdiomaFactory(language);
	}
	
	
	public void setPhoneSender(String DDD, String number)
	{
		phoneSender_ = factory.createPhone(DDD, number);
	}
	
	public void setPhoneDestinatary(String DDD, String number)
	{
		phoneDestinatary_ = factory.createPhone(DDD, number);
	}
	
	public void setSender(String nome, String email)
	{
		if(phoneSender_ == null)
		{
			throw new NullPointerException("Set Phone Sender Before");
		}
		else
		{
			sender_ = factory.createPerson(nome, email, phoneSender_);
		}
	}
	
	public void setDestinatary(String nome, String email)
	{
		if(phoneSender_ == null)
		{
			throw new NullPointerException("Set Phone Destinatary Before");
		}
		else
		{
			destinatary_ = factory.createPerson(nome, email, phoneDestinatary_);
		}
	}
	
	public void setAddressSender(String rua, int number, String resto)
	{
		addressSender_ = factory.createAddress(rua, number, resto);
	}
	
	public void setAddressDestiny(String rua, int number, String resto)
	{
		addressDestiny_ = factory.createAddress(rua, number, resto);
	}
	
	public void setDate(int dia, int mes, int ano)
	{
		date_ = factory.createDate(dia, mes, ano);
	}


	public AbstractFactory getFactory() {
		return factory;
	}


	public Person getSender_() {
		return sender_;
	}


	public Person getDestinatary_() {
		return destinatary_;
	}


	public Phone getPhoneSender_() {
		return phoneSender_;
	}


	public Phone getPhoneDestinatary_() {
		return phoneDestinatary_;
	}


	public Address getAddressSender_() {
		return addressSender_;
	}


	public Address getAddressDestiny_() {
		return addressDestiny_;
	}


	public Date getDate_() {
		return date_;
	}


	public String getLanguage_() {
		return language_;
	}
	
	
	
}
