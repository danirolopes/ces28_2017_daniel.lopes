package Ex3Ex4;

public class PhoneIngles extends Phone{
	PhoneIngles(String DDD, String number)
	{
		super("1", DDD, number);
	}
	
	public String toPrint()
	{
		return "+"+DDI_+" "+DDD_+"-"+number_;
	}
}
