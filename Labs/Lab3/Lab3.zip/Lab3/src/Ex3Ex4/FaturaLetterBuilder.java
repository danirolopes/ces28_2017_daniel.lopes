
package Ex3Ex4;

public class FaturaLetterBuilder extends LetterBuilder{
	
	public FaturaLetterBuilder(Bridge bridge)
	{
		super(bridge);
	}

	protected String header() {
		return date_.toPrint()+"\n\n"+sender_.name()+"\n"+addressSender_.toPrint()+"\n\n"+destinatary_.name()+'\n'+addressDestiny_.toPrint()+"\n";
	}

	protected String body() {
		return "\nDear "+destinatary_.name() + "\n\nAqui est� a fatura correspondente ao mes "+date_.getMes()+":\n" ;
	}

	protected String conclusion() {
		return "\n\nObrigado pela prefer�ncia,\n";
	}

	protected String signature() {
		return "\n\n                   "+ sender_.name() + "\n             SAC:"+ sender_.phone().toPrint() +	"\n            email:" + sender_.email();
	}

}//class Commercial Letter


