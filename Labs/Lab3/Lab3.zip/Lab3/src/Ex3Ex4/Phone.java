package Ex3Ex4;

public abstract class Phone {
	protected final String DDI_;
	protected final String DDD_;
	protected final String number_;
	
	protected Phone(String DDI, String DDD, String number)
	{
		DDI_ = DDI;
		DDD_ = DDD;
		number_ = number;
	}
	
	public abstract String toPrint();
}
