package Ex3Ex4;

public class PhonePortugues extends Phone{
	PhonePortugues(String DDD, String number)
	{
		super("55", DDD, number);
	}
	
	public String toPrint()
	{
		return "+"+DDI_+" ("+DDD_+") "+number_;
	}
}
