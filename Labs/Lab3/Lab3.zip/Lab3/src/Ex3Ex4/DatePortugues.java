package Ex3Ex4;

public class DatePortugues extends Date{
	DatePortugues(int dia, int mes, int ano)
	{
		super(dia, mes, ano);
	}
	
	public String toPrint()
	{
		return Integer.toString(dia_)+'/'+Integer.toString(mes_)+'/'+Integer.toString(ano_);
	}
}
