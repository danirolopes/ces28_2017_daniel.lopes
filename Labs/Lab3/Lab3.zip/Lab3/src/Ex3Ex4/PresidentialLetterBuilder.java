package Ex3Ex4;

public class PresidentialLetterBuilder extends LetterBuilder{
	public PresidentialLetterBuilder(Bridge bridge)
	{
		super(bridge);

	}

	protected String header() {
		return date_.toPrint()+"\n\n"+sender_.name()+"\n"+addressSender_.toPrint()+"\n\n"+destinatary_.name()+'\n'+addressDestiny_.toPrint()+"\n";
	}

	protected String body() {
		return "\nPresident "+destinatary_.name() + "\n" ;
	}

	protected String conclusion() {
		return "\nSincerely,\n";
	}

	protected String signature() {
		return "\n\n          __________________\n               "+ sender_.name() + "\n             " + sender_.phone().toPrint() +	"\n            email:" + sender_.email();
	}
}
