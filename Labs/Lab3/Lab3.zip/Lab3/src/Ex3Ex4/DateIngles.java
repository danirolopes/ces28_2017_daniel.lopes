package Ex3Ex4;

public class DateIngles extends Date
{
	DateIngles(int dia, int mes, int ano)
	{
		super(dia, mes, ano);
	}
	
	public String toPrint()
	{
		return Integer.toString(mes_)+'/'+Integer.toString(dia_)+'/'+Integer.toString(ano_);
	}
}
