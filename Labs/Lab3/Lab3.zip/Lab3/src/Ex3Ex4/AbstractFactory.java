package Ex3Ex4;

public abstract class AbstractFactory {
	public static AbstractFactory getIdiomaFactory(String lingua)
	{
		AbstractFactory factory = null;
		switch(lingua)
		{
			case "Ingles":
				factory = new InglesFactory();
				break;
			case "Portugues":
				factory = new PortuguesFactory();
				break;
		}
		return factory;
	}
	
	
	public abstract Date createDate(int dia, int mes, int ano);
	public abstract Address createAddress(String rua, int number, String cidadeEstadoPais);
	public abstract Phone createPhone(String DDD, String number);
	public abstract Person createPerson(String name, String email, Phone phone);

}


