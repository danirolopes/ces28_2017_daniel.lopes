package Ex1;

public class Date {
	private final int dia_;
	private final int mes_;
	private final int ano_;
	
	public Date (int dia, int mes, int ano)
	{
		dia_ = dia;
		mes_ = mes;
		ano_ = ano;
	}
	
	public String toPrint()
	{
		return Integer.toString(dia_)+'/'+Integer.toString(mes_)+'/'+Integer.toString(ano_);
	}
	
	public int getDia() {
		return dia_;
	}

	public int getMes() {
		return mes_;
	}

	public int getAno() {
		return ano_;
	}

}
