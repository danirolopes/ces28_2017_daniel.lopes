package Ex1;

public class Address {
	private final String address_;
	
	public Address(String address)
	{
		address_ = address;
	}
	
	public String toPrint()
	{
		return address_;
	}
	
	
}
