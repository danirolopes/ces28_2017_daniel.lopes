package Ex1;

public abstract class LetterBuilder {
	protected Person sender_;
	protected Person destinatary_;
	protected  Address addressSender_;
	protected  Address addressDestiny_;
	protected  Date date_;
	
	protected abstract String header();
	protected abstract String body();
	protected abstract String conclusion();
	protected abstract String signature();
	
	protected LetterBuilder(Person sender, Person destinatary, Address addressSender, Address addressDestiny, Date date)
	{
		sender_ = sender;
		destinatary_ = destinatary;
		addressSender_ = addressSender;
		addressDestiny_ = addressDestiny;
		date_ = date;
	}
	
	public Letter getLetter()
	{
		return new Letter(this);
	}
	
	
	public void setSender_(Person sender_) {
		this.sender_ = sender_;
	}

	public void setDestinatary_(Person destinatary_) {
		this.destinatary_ = destinatary_;
	}

	public void setAddressSender_(Address addressSender_) {
		this.addressSender_ = addressSender_;
	}

	public void setAddressDestiny_(Address addressDestiny_) {
		this.addressDestiny_ = addressDestiny_;
	}

	public void setDate_(Date date_) {
		this.date_ = date_;
	}
	
	public Person getSender() {
		return sender_;
	}
	
	public Person getDestinatary()
	{
		return destinatary_;
	}
	
	public Address getAddrSender() {
		return addressSender_;
	}
	
	public Address getAddrDestiny() {
		return addressDestiny_;
	}
	
	public Date getDate()
	{
		return date_;
	}
}
