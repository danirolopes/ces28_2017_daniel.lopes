package Ex1;

public class Person {
	private final String name_;
	private final String email_;
	private final Phone phone_;
	
	public Person(String name, String email, Phone phone)
	{
		name_ = name;
		email_ = email;
		phone_ = phone;
	}
	
	public String name()
	{
		return name_;
	}
	
	public String email()
	{
		return email_;
	}
	
	public Phone phone()
	{
		return phone_;
	}
}
