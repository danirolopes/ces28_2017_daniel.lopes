package Ex1;

public class Phone {
	private final String phone_;
	
	public Phone(String phone)
	{
		phone_ = phone;
	}
	
	public String toPrint()
	{
		return phone_;
	}
}
