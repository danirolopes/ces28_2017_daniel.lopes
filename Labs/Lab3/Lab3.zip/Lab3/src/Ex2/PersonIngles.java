package Ex2;

public class PersonIngles extends Person{
	PersonIngles(String name, String email, Phone phone)
	{
		super(name, email, phone);
	}
	
	public  String name()
	{
		return "Mr. "+name_;
	}
	
	public  String email()
	{
		return email_;
	}
	
}
