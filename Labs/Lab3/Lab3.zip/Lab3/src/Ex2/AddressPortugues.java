package Ex2;

public class AddressPortugues extends Address{

	AddressPortugues(String rua, int number, String resto)
	{
		super(rua, number, resto);
	}
	
	public String toPrint()
	{
		return rua_+", "+Integer.toString(number_)+", "+cidadeEstadoPais_;
	}
}
