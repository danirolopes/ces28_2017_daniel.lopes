package controller_v0;

import java.util.ArrayList;
import java.util.List;

import model_v0.GCS_Model;
import view_v0.ARP_View;
import view_v0.ARP_status;

public class UTM_CTR_Controller {
	protected List<GCS_Model> _GCSlist;
	protected List<ARP_status> _statusList;
	protected List<ARP_View> _ARPlist;
	

	//Controller is Singleton
	private UTM_CTR_Controller()
	{
		_GCSlist = new ArrayList<GCS_Model>();
		_ARPlist = new ArrayList<ARP_View>();
		_statusList = new ArrayList<ARP_status>();
	}
	
	private static class SingletonHolder {
        private static final UTM_CTR_Controller INSTANCE = new UTM_CTR_Controller();
    }

    public static UTM_CTR_Controller getInstance() {
        return SingletonHolder.INSTANCE;
    }
    //End Singleton
    
	
	public void setNewARPGCS(GCS_Model GCS, ARP_View ARP)
	{
		_ARPlist.add(ARP);
		_GCSlist.add(GCS);
		_statusList.add(new ARP_status());
	}
	
	public void update(ARP_View view)
	{
		int index = _ARPlist.indexOf(view);
		_statusList.get(index).copy(view.getState());
	}
	
	public void sendStatus()
	{
		for(int i = 0; i < _GCSlist.size(); i++)
		{
			ARP_status newStatus = _GCSlist.get(i).atualizarComando(filterStatus(i));
			_ARPlist.get(i).getNewStatus(newStatus);
		}
	}
	
	private List<ARP_status> filterStatus(int index)
	{
		//no filtering. Every model gets every state
		return _statusList;
	}
	
	public List<ARP_status> getStatus()
	{
		return _statusList;
	}
}
