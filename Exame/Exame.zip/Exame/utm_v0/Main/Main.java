package Main;

import java.util.List;

import controller_v0.UTM_CTR_Controller;
import model_v0.GCS_Model;
import view_v0.ARP_View;
import view_v0.ARP_status;

public class Main {
	public static void main(String[]args)
	{
		ARP_status s1 = new ARP_status(20,20,20);
		ARP_status s2 = new ARP_status(30,20,30);
		
		ARP_View v1= new ARP_View(s1);
		ARP_View v2= new ARP_View(s2);
		
		GCS_Model m1 = new GCS_Model();
		GCS_Model m2 = new GCS_Model();
		
		UTM_CTR_Controller controller = UTM_CTR_Controller.getInstance();
		
		controller.setNewARPGCS(m1, v1);
		controller.setNewARPGCS(m2, v2);
		
		s1 = v1.getState();
		System.out.println("Status ARP1 - Height:"+s1.get_height()+" x:"+s1.get_x()+" y: "+s1.get_y());
		
		s2 = v2.getState();
		System.out.println("Status ARP2 - Height:"+s2.get_height()+" x:"+s2.get_x()+" y: "+s2.get_y()+"\n");
		
		System.out.println("Update from ARP:");
		
		v1.sendStatus();
		v2.sendStatus();
		
		System.out.println("State List from Controller:");
		List<ARP_status> list = controller.getStatus();
		
		s1 = list.get(0);
		System.out.println("\tStatus ARP1 - Height:"+s1.get_height()+" x:"+s1.get_x()+" y: "+s1.get_y());
		
		s2 = list.get(1);
		System.out.println("\tStatus ARP2 - Height:"+s2.get_height()+" x:"+s2.get_x()+" y: "+s2.get_y()+"\n");
		
		System.out.println("State List from CGS:");
		
		if(m1.getStateList().isEmpty())
		{
			System.out.println("\tStatus CGS1 - Lista Vazia");
		}
		
		if(m2.getStateList().isEmpty())
		{
			System.out.println("\tStatus CGS2 - Lista Vazia");
		}
		
		System.out.println("\nUpdating all CGS and returning states to ARP:");
		
		controller.sendStatus();
		
		System.out.println("State List from CGS:");
		System.out.println("\tStatus CGS1:");
		s1 = m1.getStateList().get(0);
		System.out.println("\t\tHeight:"+s1.get_height()+" x:"+s1.get_x()+" y: "+s1.get_y());
		
		s2 = m1.getStateList().get(1);
		System.out.println("\t\tHeight:"+s2.get_height()+" x:"+s2.get_x()+" y: "+s2.get_y());
		
		System.out.println("\tStatus CGS2:");
		s1 = m2.getStateList().get(0);
		System.out.println("\t\tHeight:"+s1.get_height()+" x:"+s1.get_x()+" y: "+s1.get_y());
		
		s2 = m2.getStateList().get(1);
		System.out.println("\t\tHeight:"+s2.get_height()+" x:"+s2.get_x()+" y: "+s2.get_y());
		
		System.out.println("States of ARP send by CGS: (Hardcoded)");
		s1 = v1.getState();
		System.out.println("\tStatus ARP1 - Height:"+s1.get_height()+" x:"+s1.get_x()+" y: "+s1.get_y());
		
		s2 = v2.getState();
		System.out.println("\tStatus ARP2 - Height:"+s2.get_height()+" x:"+s2.get_x()+" y: "+s2.get_y()+"\n");
		
		
	}
}
