package model_v0;

import java.util.ArrayList;
import java.util.List;

import view_v0.ARP_status;

public class GCS_Model {
	protected List<ARP_status> _stateList;
	
	public GCS_Model()
	{
		_stateList = new ArrayList<ARP_status>();
	}
	
	public ARP_status atualizarComando(List<ARP_status> list)
	{
		_stateList = list;
		return new ARP_status(10, 10, 10);
	}
	
	public List<ARP_status> getStateList()
	{
		return _stateList;
	}
	
}
