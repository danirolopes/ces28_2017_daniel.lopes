package view_v0;

import view_v0.ARP_status;

public class ARP_status {
	private float _height;
	private float _x;
	private float _y;
	
	public ARP_status(float _height, float _x, float _y) {
		this._height = _height;
		this._x = _x;
		this._y = _y;
	}
	
	public ARP_status() {
	}
	
	public float get_height() {
		return _height;
	}
	public void set_height(float _height) {
		this._height = _height;
	}
	public float get_x() {
		return _x;
	}
	public void set_x(float _x) {
		this._x = _x;
	}
	public float get_y() {
		return _y;
	}
	public void set_y(float _y) {
		this._y = _y;
	}
	
	public void copy(ARP_status status)
	{
		_height = status.get_height();
		_x = status.get_x();
		_y = status.get_y();
	}
	
}
