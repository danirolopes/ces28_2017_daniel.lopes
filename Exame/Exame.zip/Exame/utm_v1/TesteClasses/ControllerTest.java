package TesteClasses;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import controller_v1.UTM_CTR_Controller;
import model_v1.GCS_Model;
import view_v1.ARP_View;
import view_v1.ARP_status;

public class ControllerTest {

	@InjectMocks private  ARP_View v1;
	@InjectMocks private  ARP_View v2;
	@Mock  private  GCS_Model m1;
	@Mock  private  GCS_Model m2;
	private  ARP_status s1;
	private  ARP_status s2;
	
	private  UTM_CTR_Controller controller;
	
	@Before
	public void before() {
		MockitoAnnotations.initMocks(this);

		s1 = new ARP_status(20, 20, 10);
		s2 = new ARP_status(30, 10, 20);
		
		controller = UTM_CTR_Controller.getInstance();
		
		v1 = new ARP_View(s1, controller);
		v2 = new ARP_View(s2, controller);
		
		controller.eraseController();
		
		controller.setNewARPGCS(m1, v1);
		controller.setNewARPGCS(m2, v2);
	}
	
	@Test
	public void testThatOnlyHasOneInstance()
	{
		UTM_CTR_Controller c1, c2;
		
		c1 = UTM_CTR_Controller.getInstance();
		c2 = UTM_CTR_Controller.getInstance();
		
		assertTrue(c1 == c2);
	}
	
	@Test
	public void controllerOnlyUpdatesStatesWhenRequested()
	{
		List<ARP_status> listStatus = new ArrayList<ARP_status>();
		listStatus.add(s1);
		listStatus.add(s2);
				
		assertTrue(!controller.getStatus().equals(listStatus));
		
		v1.sendStatus();
		v2.sendStatus();
				
		assertTrue(controller.getStatus().equals(listStatus));
	}
	
	@Test
	public void controllerUpdatesModelAndReturnNewStatusForView()
	{
		ARP_status s3 = new ARP_status(10,10,10);
		ARP_status s4 = new ARP_status(10,40,40);
		
		Mockito.when(m1.atualizarComando(Mockito.any())).thenReturn(s3);
		Mockito.when(m2.atualizarComando(Mockito.any())).thenReturn(s4);
		
		
		v1.sendStatus();
		v2.sendStatus();		
		
		controller.sendStatus();
		
		assertTrue(v1.getState().equals(s3));
		assertTrue(v2.getState().equals(s4));
		
		
	}

}
