package TesteClasses;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import controller_v1.UTM_CTR_Controller;
import view_v1.ARP_View;
import view_v1.ARP_status;

public class ViewTest {

	@Mock private UTM_CTR_Controller controller;
	private ARP_View view;
	private ARP_status s1;
	private ARP_status s2;
	
	@Before
	public void setup()
	{
		MockitoAnnotations.initMocks(this);
		
		s1 = new ARP_status(10, 10, 10);
		s2 = new ARP_status(20,20,20);
		view = new ARP_View(s1, controller);
	}
	
	@SuppressWarnings("rawtypes")
	@Test
	public void viewUpdatesControllerThenGetsFeedback()
	{
		Mockito.doAnswer(new Answer() {
		   public Object answer(InvocationOnMock invocation){
		        Object[] args = invocation.getArguments();
		        
		        ((ARP_View)args[0]).getNewStatus(s2);        
		        
		        return null;
		   }			
		}).when(controller).update(Mockito.any());
		
		assertTrue(view.getState().equals(s1));
		
		view.sendStatus();
		
		assertTrue(view.getState().equals(s2));
	}
	
}
