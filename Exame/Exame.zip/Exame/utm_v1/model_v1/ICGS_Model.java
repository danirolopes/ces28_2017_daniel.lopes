package model_v1;

import java.util.List;

import view_v1.ARP_status;

public interface ICGS_Model {
	public ARP_status atualizarComando(List<ARP_status> list);
}
