package view_v1;

import controller_v1.UTM_CTR_Controller;
import view_v1.ARP_status;

public class ARP_View {
	protected ARP_status _state;
	protected UTM_CTR_Controller _controller;
	protected ARP_status _update_state;
	
	public ARP_View(ARP_status status, UTM_CTR_Controller controller)
	{
		_controller = controller;
		_state = status;
	}
	
	public void sendStatus()
	{
		_controller.update(this);
	}
	
	public ARP_status getState()
	{
		return _state;
	}
	
	
	public void getNewStatus(ARP_status status)
	{
		_state = status;
	}
}
