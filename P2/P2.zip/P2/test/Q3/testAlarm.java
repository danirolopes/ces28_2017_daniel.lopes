package Q3;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import Q3.refatorado.Alarm;
import Q3.refatorado.Sensor;

public class testAlarm {
	
	private final double LowPressureThreshold = 17;
	private final double HighPressureThreshold = 24;
	
	@Mock private Sensor sensor;
	@InjectMocks private Alarm alarm = new Alarm(sensor, LowPressureThreshold, HighPressureThreshold);
	
	@Before
	public void setup()
	{
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testAlarmOnWhen25() throws Exception {
		Mockito.when(sensor.popNextPressurePsiValue()).thenReturn(25.0);
		
		Assert.assertTrue(alarm.isAlarmOn());
	}
	
	@Test
	public void testAlarmOnWhen16() throws Exception{
		Mockito.when(sensor.popNextPressurePsiValue()).thenReturn(16.0);
		
		Assert.assertTrue(alarm.isAlarmOn());
	}
	
	@Test
	public void testAlarmOffWhen18() throws Exception{
		Mockito.when(sensor.popNextPressurePsiValue()).thenReturn(18.0);
		
		Assert.assertFalse(alarm.isAlarmOn());
	}
	
	@Test
	public void testAlarmOffWhen24() throws Exception{
		Mockito.when(sensor.popNextPressurePsiValue()).thenReturn(24.0);
		
		Assert.assertFalse(alarm.isAlarmOn());
	}

}
