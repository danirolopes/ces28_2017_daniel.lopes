package Q4;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import Q4.refatorado.itemC.Calculadora;
import Q4.refatorado.itemC.Despesa;
import Q4.refatorado.itemC.Impressora;
import Q4.refatorado.itemC.RelatorioDespesas;
import Q4.refatorado.itemC.SistemaOperacional;

public class testRelatorioDespesasItemC {

	@InjectMocks private RelatorioDespesas relDesp;
	@InjectMocks private SistemaOperacional so;
	@Mock private Despesa d1;
	@Mock private Despesa d2;
	@Mock private Despesa d3;
	@Mock private Despesa d4;
	@Mock private Calculadora calc;
	@Mock private Impressora imp;
			
	@Before
	public void setup()
	{
		MockitoAnnotations.initMocks(this);
		
		so = new SistemaOperacional(imp);
		relDesp = new RelatorioDespesas(calc, so);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testListaSemDespesas() throws IllegalArgumentException
	{
		ArrayList<Despesa> listaDespesas = new ArrayList<Despesa>();	
		relDesp.imprimirRelatorio(listaDespesas);
	}
	
	@Test
	public void testListaComDespesas0ImpressoraOK() throws Exception
	{
		Mockito.when(d1.getDespesa()).thenReturn(0.0f);
		Mockito.when(d2.getDespesa()).thenReturn(0.0f);
		Mockito.when(d3.getDespesa()).thenReturn(0.0f);
		Mockito.when(d4.getDespesa()).thenReturn(0.0f);
		
		Mockito.when(calc.finalSum(Mockito.any())).thenReturn(0.0f);
		
		Mockito.when(imp.getTipoImpressora()).thenReturn("Laser");
		
		
		ArrayList<Despesa> listaDespesas = new ArrayList<Despesa>();
		
		listaDespesas.add(d1);
		listaDespesas.add(d2);
		listaDespesas.add(d3);
		listaDespesas.add(d4);
		
		relDesp.imprimirRelatorio(listaDespesas);
		
		assertEquals(relDesp.getRelatorio(listaDespesas), "Relat�rio de Despesas\nTotal das despesas: 0.0");
	}
	
	@Test
	public void testListaComDespesas100ImpressoraOK() throws Exception
	{
		Mockito.when(d1.getDespesa()).thenReturn(45.0f);
		Mockito.when(d2.getDespesa()).thenReturn(30.0f);
		Mockito.when(d3.getDespesa()).thenReturn(25.0f);
		Mockito.when(d4.getDespesa()).thenReturn(0.0f);
		Mockito.when(calc.finalSum(Mockito.any())).thenReturn(100.0f);
		
		Mockito.when(imp.getTipoImpressora()).thenReturn("Jato de Tinta");
		
		
		ArrayList<Despesa> listaDespesas = new ArrayList<Despesa>();
		
		listaDespesas.add(d1);
		listaDespesas.add(d2);
		listaDespesas.add(d3);
		listaDespesas.add(d4);
		
		relDesp.imprimirRelatorio(listaDespesas);
		
		assertEquals(relDesp.getRelatorio(listaDespesas), "Relat�rio de Despesas\nTotal das despesas: 100.0");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testListaComDespesas0ImpressoraMatricial() throws IllegalArgumentException
	{
		Mockito.when(d1.getDespesa()).thenReturn(0.0f);
		Mockito.when(d2.getDespesa()).thenReturn(0.0f);
		Mockito.when(d3.getDespesa()).thenReturn(0.0f);
		Mockito.when(d4.getDespesa()).thenReturn(0.0f);
		
		Mockito.when(calc.finalSum(Mockito.any())).thenReturn(0.0f);
		
		Mockito.when(imp.getTipoImpressora()).thenReturn("Matricial");
		
		
		ArrayList<Despesa> listaDespesas = new ArrayList<Despesa>();
		
		listaDespesas.add(d1);
		listaDespesas.add(d2);
		listaDespesas.add(d3);
		listaDespesas.add(d4);
		
		relDesp.imprimirRelatorio(listaDespesas);
		
		assertEquals(relDesp.getRelatorio(listaDespesas), "Relat�rio de Despesas\nTotal das despesas: 0.0");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testListaComDespesas100ImpressoraMatricial() throws IllegalArgumentException
	{
		Mockito.when(d1.getDespesa()).thenReturn(45.0f);
		Mockito.when(d2.getDespesa()).thenReturn(30.0f);
		Mockito.when(d3.getDespesa()).thenReturn(25.0f);
		Mockito.when(d4.getDespesa()).thenReturn(0.0f);
		Mockito.when(calc.finalSum(Mockito.any())).thenReturn(100.0f);
		
		Mockito.when(imp.getTipoImpressora()).thenReturn("Matricial");
		
		
		ArrayList<Despesa> listaDespesas = new ArrayList<Despesa>();
		
		listaDespesas.add(d1);
		listaDespesas.add(d2);
		listaDespesas.add(d3);
		listaDespesas.add(d4);
		
		relDesp.imprimirRelatorio(listaDespesas);
		
		assertEquals(relDesp.getRelatorio(listaDespesas), "Relat�rio de Despesas\nTotal das despesas: 100.0");
	}

}
