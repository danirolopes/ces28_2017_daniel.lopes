package Q3.refatorado;


public class Alarm
{
    private final double LowPressureThreshold;
    private final double HighPressureThreshold;
    private Sensor _sensor;
    private boolean _alarmOn = false;
    
    public Alarm(Sensor sensor, double lowerBounder, double higherBounder)
    {
    	_sensor = sensor;
    	LowPressureThreshold = lowerBounder;
    	HighPressureThreshold = higherBounder;
    }

    private void checkPressure()
    {
        double psiPressureValue = _sensor.popNextPressurePsiValue();

        if (psiPressureValue < LowPressureThreshold || HighPressureThreshold < psiPressureValue)
        {
            _alarmOn = true;
        }
        else
        {
        	_alarmOn = false;
        }
    }

    public boolean isAlarmOn()
    {
    	this.checkPressure();
    	
        return _alarmOn; 
    }
}