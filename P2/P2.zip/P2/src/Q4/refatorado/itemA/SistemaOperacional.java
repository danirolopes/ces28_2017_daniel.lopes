package Q4.refatorado.itemA;

public class SistemaOperacional {
	public Impressora getDriverImpressao() {
		return new Impressora();
	}
}
