package Q4.refatorado.itemA;

import java.util.List;

public class RelatorioDespesas {
	
	private Calculadora _calc;
	
	public RelatorioDespesas(Calculadora calc)
	{
		_calc = calc;
	}
	
	public void imprimirRelatorio(List<Despesa> despesas) {
		
		if (despesas==null || despesas.isEmpty()) {
			throw new IllegalArgumentException("conteudo nulo");
		}
		
		Impressora impressora;
		
		String relatorio = this.getRelatorio(despesas);

		SistemaOperacional so = new SistemaOperacional();
		impressora = so.getDriverImpressao();
		
		impressora.imprimir(relatorio);
	}
	
	public String getRelatorio(List<Despesa> despesas)
	{
		float totalDespesa;
		
		totalDespesa = _calc.finalSum(despesas);
		
		String relatorio = "Relat�rio de Despesas";
		relatorio+=("\nTotal das despesas: " + totalDespesa);
		
		return relatorio;
	}
}