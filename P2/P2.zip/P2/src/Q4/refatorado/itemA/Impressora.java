package Q4.refatorado.itemA;

public class Impressora {
	
	public void imprimir(String conteudo) {
			System.out.println(conteudo);
	}
	
	
}
