package Q4.refatorado.itemA;

import java.util.Iterator;
import java.util.List;

public class Calculadora {
	
	public float finalSum(List<Despesa> despesas) {
		float soma = 0.0f;
		
		Iterator<Despesa> despesaIt = despesas.iterator();
		
		while (despesaIt.hasNext()) {
			Despesa desp = despesaIt.next();
			soma += desp.getDespesa();
		}
		
		return soma;
	}
}
