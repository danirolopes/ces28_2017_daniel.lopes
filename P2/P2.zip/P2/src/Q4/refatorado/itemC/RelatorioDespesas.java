package Q4.refatorado.itemC;

import java.util.List;

public class RelatorioDespesas {
	
	private Calculadora _calc;
	private SistemaOperacional _so;
	
	public RelatorioDespesas(Calculadora calc, SistemaOperacional so)
	{
		_calc = calc;
		_so = so;
	}
	
	public void imprimirRelatorio(List<Despesa> despesas) {
		
		if (despesas==null || despesas.isEmpty()) {
			throw new IllegalArgumentException("conteudo nulo");
		}
		
		Impressora impressora;
		
		String relatorio = this.getRelatorio(despesas);

		
		//Verificando se a impressora consegue ser inicializada pelo sistema operacional
		try{
			impressora = _so.getDriverImpressao();
		}
		catch(IllegalArgumentException e)
		{
			//A exception � carregada para classes que chamaram esse m�todo
			throw e;
		}
		
		impressora.imprimir(relatorio);
	}
	
	public String getRelatorio(List<Despesa> despesas)
	{
		float totalDespesa;
		
		totalDespesa = _calc.finalSum(despesas);
		
		String relatorio = "Relat�rio de Despesas";
		relatorio+=("\nTotal das despesas: " + totalDespesa);
		
		return relatorio;
	}
}