package Q4.refatorado.itemC;

public class Impressora {
	
	private String tipoImpressora;
	
	public void imprimir(String conteudo) {
			System.out.println(conteudo);
	}
	
	public String getTipoImpressora()
	{
		return tipoImpressora;
	}
}
