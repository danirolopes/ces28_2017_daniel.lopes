package Q4.refatorado.itemC;

public class SistemaOperacional {
	private Impressora _impressora;
	
	public SistemaOperacional(Impressora impressora)
	{
		_impressora = impressora; 
	}
	
	
	public Impressora getDriverImpressao() {
		if(_impressora.getTipoImpressora().equals("Matricial"))
		{
			throw new IllegalArgumentException("Tipo de Impressora Inv�lido");
		}
		
		return _impressora;
	}
}
