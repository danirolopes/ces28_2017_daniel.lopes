package Q4.orig;

public class Despesa {
	float total= 0.0f;
	
	public Despesa(float total) {
		this.total= total;
	}

	public float getDespesa() {
		return total;
	}
	
}
