package Q4.orig;

public class SistemaOperacional {
	public Impressora getDriverImpressao() {
		return new Impressora();
	}
}
